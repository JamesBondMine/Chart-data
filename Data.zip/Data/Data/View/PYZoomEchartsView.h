//
//  PYZoomEchartsView.h
//  iOS-Echarts
//
//  Created by Pluto Y on 16/4/5.
//  Copyright © 2016年 pluto-y. All rights reserved.
//

#import "PYEchartsView.h"

@interface PYZoomEchartsView : PYEchartsView

@end
