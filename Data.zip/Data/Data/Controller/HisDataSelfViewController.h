//
//  HisDataSelfViewController.h
//  Data
//
//  Created by hipiao on 16/9/1.
//  Copyright © 2016年 James. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HisDataSelfViewController : UIViewController

@end
