//
//  DataBrokenViewController.h
//  Data
//
//  Created by hipiao on 16/8/29.
//  Copyright © 2016年 James. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PYEchartsView.h"
#import "PYZoomEchartsView.h"

@interface DataBrokenViewController : UIViewController


@property (nonatomic,strong) IBOutlet UIButton * btnView;
@end
